### Hexlet tests and linter status:
[![Actions Status](https://github.com/Roodmann/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Roodmann/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5711a9d34ef637051a20/maintainability)](https://codeclimate.com/github/Roodmann/python-project-49/maintainability)
####  Четное или нечетное [демонстрация](https://asciinema.org/a/h0Jcsz6FZgQfCFTQMl02xqhn1) 
	
####  Калькулятор [демонстрация](https://asciinema.org/a/jrgFZG7Ip3yayX56TxvrT4H06)
